<?php
require 'database-connect.php';

// Check if the form is submitted
if (isset($_POST["save"])) {
    $newUsername = $_POST["newuser"];
    $oldUsername = $_POST["olduser"];
    $sql = "UPDATE users SET username = '$newUsername' WHERE username = '$oldUsername'";
    if ($conn->query($sql) === true) {
        header('Location: signed-account.php');
    } else {
        echo "<script>alert('ERROR!!!!')</script>";
    }
}

?>

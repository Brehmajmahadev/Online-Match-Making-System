<?php
require_once 'database-connect.php';

// Check if the login form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['uname'];
    $password = $_POST['pass'];

    // Query to check if the username and password match in the database
    $query = "SELECT * FROM admin WHERE admin_username = '$username' AND admin_password = '$password'";
    $result = $conn->query($query);

    if ($result->num_rows == 1) {
        // User credentials are correct, log in the user
        session_start();
        $_SESSION['admin_username'] = $username;
        // Redirect to a logged-in page
        header('Location: admin-home.php');
        exit();
    } else {
        // Invalid login credentials
        echo "<script>alert('Invalid Username or Password')</script>";
    }
}
?>

<?php
require 'database-connect.php';

// Check if the form is submitted
if (isset($_POST["save"])) {
    $newTeamName = $_POST["newtname"];
    $oldTeamName = $_POST["oldtname"];
    $sql = "UPDATE users SET team_name = '$newTeamName' WHERE team_name = '$oldTeamName'";
    if ($conn->query($sql) === true) {
        header('Location: signed-account.php');
    } else {
        echo "<script>alert('ERROR!!!!')</script>";
    }
}

?>

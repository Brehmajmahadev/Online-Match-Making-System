<?php
require 'database-connect.php';

if (isset($_POST['register'])) {
    $tourid = $_POST['tourid'];
    $teamname = $_POST['ttname'];
    $managername = $_POST['tmname'];
    $phone = $_POST['phonenum'];
    $query = "INSERT INTO registeredteams (tournament_id, manager_name, team_name, phone_number) VALUES ('$tourid', '$managername', '$teamname', '$phone')";
    $result = mysqli_query($conn, $query);
    header('Location: tournaments-signed.php');
    exit();
} else {
    echo "<script>alert('ERROR!!!')</script>";
}
?>

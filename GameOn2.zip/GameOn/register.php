<?php
require 'database-connect.php';

if (isset($_POST['create'])) {
    $username = $_POST['uname'];
    $email = $_POST['mail'];
    $password = $_POST['pass'];
    $cpassword = $_POST['cpass'];
    $teamname = $_POST['team'];
    $managername = $_POST['manager'];

    if ($password == $cpassword) {
        $query = "INSERT INTO users (username, email, pass, team_name, manager_name) VALUES ('$username', '$email', '$password', '$teamname', '$managername')";
        // Execute the query
        $result = mysqli_query($conn, $query);

        // Redirect the user to the signin.html page
        header('Location: signin.html');
        exit();
    } else {
        echo "<script>alert('Password Do Not Match')</script>";
    }
}
?>

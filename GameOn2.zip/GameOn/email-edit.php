<?php session_start(); ?>
<?php
if (!isset($_SESSION['username'])) {
  header ('Location: signin.html');
  exit();
}
require 'database-connect.php';
$user= $_SESSION['username'];
// Retrieve user data from the database
$query = "SELECT username, email, pass, team_name, manager_name FROM users WHERE username= '$user'";
$result = mysqli_query($conn, $query);

// Check if any records were found
if (mysqli_num_rows($result) > 0) {
    $userData = mysqli_fetch_assoc($result);
} else {
    $userData = array(); // Empty array if no records found
}

?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GameOn</title>
    <link rel="icon" href="media/logo.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="css/email-edit.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap" rel="stylesheet">
  </head>
  <body style="background-color: #DAFFFB;">
    <!-- Section 1 Navigation -->
    <section id="section1">
        <nav class="navigation navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
              <a style="color: white;" class="navbar-brand" href="signed-home.php">
                <img src="media/logo.png" width="35px" height="35px" alt="logo">
                GameOn
              </a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <li class="nav-item">
                    <a style="color: white;" class="nav-link active" aria-current="page" href="signed-home.php">Home</a>
                  </li>
                  <li class="nav-item">
                    <a style="color: white;" class="nav-link" href="tournaments-signed.php">Tournaments</a>
                  </li>
                  <li class="nav-item">
                    <a style="color: white;" class="nav-link" href="teams-signed.php">Teams</a>
                  </li>
                  <li class="nav-item">
                    <a style="color: white;" class="nav-link" href="#section3">Contact Us</a>
                  </li>
                  <li class="nav-item dropdown">
                    <a style="color: white;" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      Your Account
                    </a>
                    <ul class="dd dropdown-menu">
                      <li><a class="ddi dropdown-item" href="signed-account.php"><?php echo $_SESSION['username']; ?></a></li>
                      <li><a class="ddi dropdown-item" href="terminate-session.php">Sign Out</a></li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
    </section>
    <section id="section2">
      <div class="container change-email-div">
        <form action="email-change.php" method="post" class="change-email">
          <h2 class="email-change-head" style="color: white; font-family: 'Roboto Condensed', sans-serif;">Change Your E-Mail</h2>
          <br>
          <label for="cu-mail" class="cumail">Current E-Mail</label>
          <br>
          <input type="email" class="email-input" value="<?php echo $userData['email']; ?>" name="oldemail" id="oldemail">
          <br><br>
          <label for="new-email" class="newemail">New E-Mail</label>
          <br>
          <input type="email" class="email-input" placeholder="Enter New E-Mail" name="newemail" id="newemail">
          <br><br>
          <input type="submit" name="save" id="save" class="btn btn-primary email-save" value="Save">
        </form>
      </div>
    </section>
    <section id="section3">
      <nav class="bottombar navbar bottom navbar-expand-sm ">
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto bottom-ul">
            <li class="nav-item">
              <a style="color: white;" class="nav-link" href="#"><i class="fa-brands fa-instagram"></i></a>
            </li>
            <li class="nav-item">
              <a style="color: white;" class="nav-link" href="#"><i class="fa-brands fa-facebook"></i></a>
            </li>
            <li class="nav-item">
              <a style="color: white;" class="nav-link" href="mailto:support@gameon.com"><i class="fa-solid fa-envelope"></i></a>
            </li>
            <li class="nav-item">
              <a style="color: white;" class="nav-link" href="#"><i class="fa-brands fa-linkedin"></i></a>
            </li>
          </ul>
          <ul class="navbar-nav mr-auto copy-ul">
            <li class="nav-item">
              <a style="color: white;" href="" class="nav-link copyright">Copyright 2023&copy;</a>
            </li>
          </ul>
        </div>
      </nav>  
    </section>
  </body>
  <script src="https://kit.fontawesome.com/b0aecfaa24.js" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
</html>
<?php
require 'database-connect.php';

if (isset($_POST['create'])) {
    $tourname = $_POST['tourname'];
    $tourtype = $_POST['ttype'];
    $toursdate = $_POST['tdate'];
    $touredate = $_POST['tedate'];
    $tourtime = $_POST['ttime'];
    $tourstatus = $_POST['status'];
    $query = "INSERT INTO tournaments (tournament_name, tournament_type, start_date, end_date, time, status) VALUES ('$tourname', '$tourtype', '$toursdate', '$touredate', '$tourtime', '$tourstatus')";
    $result = mysqli_query($conn, $query);
    header('Location: admin-tournament-control.php');
    exit();
} else {
    echo "<script>alert('ERROR!!!')</script>";
}
?>

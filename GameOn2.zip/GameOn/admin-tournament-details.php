<?php session_start(); ?>
<?php
if (!isset($_SESSION['admin_username'])) {
  header ('Location: admin-signin.html');
  exit();
}
$user = $_SESSION['admin_username'];
require 'database-connect.php';
$tourid = $_GET['tid'];
$query = "SELECT tournament_name, tournament_type, start_date, end_date, time FROM tournaments WHERE tournament_id = $tourid";
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) > 0) {
    $userData = mysqli_fetch_assoc($result);
    $tourname = $userData['tournament_name'];
    $tourtype = $userData['tournament_type'];
    $toursdate = $userData['start_date'];
    $touredate = $userData['end_date'];
    $tourtime = $userData['time'];
}
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GameOn</title>
    <link rel="icon" href="media/logo.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="css/tournament-details.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap" rel="stylesheet">
  </head>
  <body style="background-color: #DAFFFB;">
    <!-- Section 1 Navigation -->
    <section id="section1">
        <nav class="navigation navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
              <a style="color: white;" class="navbar-brand" href="admin-home.php">
                <img src="media/logo.png" width="35px" height="35px" alt="logo">
                GameOn
              </a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <li class="nav-item">
                    <a style="color: white;" class="nav-link" aria-current="page" href="admin-home.php">Home</a>
                  </li>
                  <li class="nav-item">
                    <a style="color: white;" class="nav-link active" href="admin-tournament-control.php">Tournaments</a>
                  </li>
                  <li class="nav-item">
                    <a style="color: white;" class="nav-link" href="admin-teams.php">Teams</a>
                  </li>
                  <li class="nav-item">
                    <a style="color: white;" class="nav-link" href="#section3">Contact Us</a>
                  </li>
                  <li class="nav-item dropdown">
                    <a style="color: white;" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <?php echo $_SESSION['admin_username']; ?>
                    </a>
                    <ul class="dd dropdown-menu">
                      <li><a class="ddi dropdown-item" href="terminate-session.php">Sign Out</a></li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
    </section>
    <section style="font-family: 'Roboto Condensed', sans-serif;" id="section2">
      <div class="container-fluid tournament-div">
        <div class="container t-details-div">
          <h2 class="todetails-head" style="color: white;">Tournament Details</h2>
          <h6 class="detail-head">Tournament Name:</h6>
          <p><?php echo "$tourname" ?></p>
          <h6 class="detail-head">Tournament Type:</h6>
          <p><?php echo "$tourtype" ?></p>
          <h6 class="detail-head">Tournament Start Date:</h6>
          <p><?php echo "$toursdate" ?></p>
          <h6 class="detail-head">Tournament End Date:</h6>
          <p><?php echo "$touredate" ?></p>
          <h6 class="detail-head">Tournament Time(24HR):</h6>
          <p><?php echo "$tourtime" ?></p>
        </div>
        <?php
        $q = "SELECT * FROM registeredteams WHERE tournament_id = $tourid";
        $result = $conn->query($q);
        ?>
        <div class="container table-div">
          <h2 class="ctms-head" style="color: white;">Competing Teams</h2>
          <table class="table table-warning table-team">
            <thead>
              <tr>
                <th>Team Name</th>
                <th>Team Manager</th>
                <th>Contact Number</th>
              </tr>
            </thead>
              <tbody>
              <?php while ($rteams = $result->fetch_assoc()): ?>
                <tr>
                  <td><?php echo $rteams['team_name']; ?></td>
                  <td><?php echo $rteams['manager_name']; ?></</td>
                  <td><?php echo $rteams['phone_number']; ?></</td>
                </tr>
                <?php endwhile; ?>                     
              </tbody>
            </table>
          </div>
        </div>
    </section>
    <section id="section2a">
        <div class="container-fluid ad-image">
          <img style="border-radius:5px;" class="rounded-start banner-image" src="media/banner.png" alt="webbanner">
        </div>
    </section>
    <section id="section3">
      <nav class="bottombar navbar bottom navbar-expand-sm ">
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto bottom-ul">
            <li class="nav-item">
              <a style="color: white;" class="nav-link" href="#"><i class="fa-brands fa-instagram"></i></a>
            </li>
            <li class="nav-item">
              <a style="color: white;" class="nav-link" href="#"><i class="fa-brands fa-facebook"></i></a>
            </li>
            <li class="nav-item">
              <a style="color: white;" class="nav-link" href="mailto:support@gameon.com"><i class="fa-solid fa-envelope"></i></a>
            </li>
            <li class="nav-item">
              <a style="color: white;" class="nav-link" href="#"><i class="fa-brands fa-linkedin"></i></a>
            </li>
          </ul>
          <ul class="navbar-nav mr-auto copy-ul">
            <li class="nav-item">
              <a style="color: white;" href="" class="nav-link copyright">Copyright 2023&copy;</a>
            </li>
          </ul>
        </div>
      </nav>  
    </section>
  </body>
  <script src="https://kit.fontawesome.com/b0aecfaa24.js" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
</html>
<?php
session_start();
require 'database-connect.php';
$username = $_SESSION['username'];
if (isset($_POST["add"])) {
    $achievement = $_POST["achieve"];
    $sql = "INSERT INTO achievements (achievement, username) VALUES ('$achievement','$username')";
    if ($conn->query($sql) === true) {
        header('Location: signed-account.php');
    } else {
        echo "<script>alert('ERROR!!!!')</script>";
    }
}
?>
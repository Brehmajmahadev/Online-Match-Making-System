<?php
require 'database-connect.php';

if (isset($_POST['delete'])) {
    $tourid = $_POST['tourid'];
    $query = "DELETE FROM tournaments WHERE tournament_id='$tourid'";
    $result = mysqli_query($conn, $query);
    header('Location: admin-tournament-control.php');
    exit();
} else {
    echo "<script>alert('ERROR!!!')</script>";
}

?>
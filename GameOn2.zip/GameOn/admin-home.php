<?php 
session_start(); 
if (!isset($_SESSION['admin_username'])) {
  header ('Location: admin-signin.html');
  exit();
}
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GameOn</title>
    <link rel="icon" href="media/logo.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="css/admin-home.css">
  </head>
  <body style="background-color: #DAFFFB;">
    <!-- Section 1 Navigation -->
    <section id="section1">
        <nav class="navigation navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
              <a style="color: white;" class="navbar-brand" href="admin-home.php">
                <img src="media/logo.png" width="35px" height="35px" alt="logo">
                GameOn
              </a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <li class="nav-item">
                    <a style="color: white;" class="nav-link active" aria-current="page" href="admin-home.php">Home</a>
                  </li>
                  <li class="nav-item">
                    <a style="color: white;" class="nav-link" href="admin-tournament-control.php">Tournaments</a>
                  </li>
                  <li class="nav-item">
                    <a style="color: white;" class="nav-link" href="admin-teams.php">Teams</a>
                  </li>
                  <li class="nav-item">
                    <a style="color: white;" class="nav-link" href="#section3">Contact Us</a>
                  </li>
                  <li class="nav-item dropdown">
                    <a style="color: white;" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <?php echo $_SESSION['admin_username']; ?>
                    </a>
                    <ul class="dd dropdown-menu">
                      <li><a class="ddi dropdown-item" href="terminate-session.php">Sign Out</a></li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
    </section>
    <section id="section1a">
      <div class="container-fluid ad-image">
        <img style="border-radius: 5px;" class="rounded-start banner-image shadow" src="media/banner.png" alt="webbanner">
      </div>
    </section>
    <section id="section2">
      <div class="container-fluid main-div">
        <img class="main-image" style="width:100%;" src="media/main.png" alt="main">
      </div>
      <div class="tcard card mb-3 shadow" style="max-width: 540px;">
        <div class="row g-0">
          <div class="col-md-4">
            <img src="media/tt.png" class="img-fluid rounded-start tmnt-image" alt="timage">
          </div>
          <div class="col-md-8">
            <div class="card-body">
              <h5 class="card-title">Tournaments</h5>
              <p class="card-text">Register for your favourite tournaments and become the best team ever!!!</p>
              <a href="admin-tournament-control.php" class="btn btn-primary">View</a>
            </div>
          </div>
        </div>
      </div>
      <div class="d-card card mb-3 shadow" style="max-width: 540px; position:relative; top: 4px;">
        <div class="row g-0">
          <div class="col-md-4">
            <img src="media/duk.png" class="img-fluid duk-image rounded-start" alt="bulb">
          </div>
          <div class="col-md-8">
            <div class="card-body">
              <h5 class="card-title">Teams Of GameOn</h5>
              <p class="card-text">Click this card to view teams registered in this website</p>
              <a href="admin-teams.php" class="btn btn-primary">View</a>
            </div>
          </div>
        </div>
      </div> 
    </section>
    <section id="section3">
      <nav class="bottombar navbar bottom navbar-expand-sm ">
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto bottom-ul">
            <li class="nav-item">
              <a style="color: white;" class="nav-link" href="#"><i class="fa-brands fa-instagram"></i></a>
            </li>
            <li class="nav-item">
              <a style="color: white;" class="nav-link" href="#"><i class="fa-brands fa-facebook"></i></a>
            </li>
            <li class="nav-item">
              <a style="color: white;" class="nav-link" href="mailto:support@gameon.com"><i class="fa-solid fa-envelope"></i></a>
            </li>
            <li class="nav-item">
              <a style="color: white;" class="nav-link" href="#"><i class="fa-brands fa-linkedin"></i></a>
            </li>
          </ul>
          <ul class="navbar-nav mr-auto copy-ul">
            <li class="nav-item">
              <a style="color: white;" href="" class="nav-link copyright">Copyright 2023&copy;</a>
            </li>
          </ul>
        </div>
      </nav>  
    </section>
  </body>
  <script src="https://kit.fontawesome.com/b0aecfaa24.js" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
</html>
<?php
require 'database-connect.php';
session_start();
$username = $_SESSION['username'];
$query = "SELECT username, email, pass, team_name, manager_name FROM users WHERE username = '$username'";
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) > 0) {
    $userData = mysqli_fetch_assoc($result);
} else {
    $userData = array(); 
}
$currentp = $userData['pass'];
if (isset($_POST["save"])) {
    $newpass = $_POST["newpass"];
    $oldpass = $_POST["oldpass"];
    if ($oldpass == $currentp) {
        $sql = "UPDATE users SET pass = '$newpass' WHERE username = '$username'";
        if ($conn->query($sql) === true) {
            header('Location: signed-account.php');
        } else {
            echo "<script>alert('ERROR!!!!')</script>";
        }
    }
}

?>

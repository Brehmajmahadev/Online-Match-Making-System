<?php
require 'database-connect.php';

// Check if the form is submitted
if (isset($_POST["save"])) {
    $newEmail = $_POST["newemail"];
    $oldEmail = $_POST["oldemail"];
    $sql = "UPDATE users SET email = '$newEmail' WHERE email = '$oldEmail'";
    if ($conn->query($sql) === true) {
        header('Location: signed-account.php');
    } else {
        echo "<script>alert('ERROR!!!!')</script>";
    }
}

?>
